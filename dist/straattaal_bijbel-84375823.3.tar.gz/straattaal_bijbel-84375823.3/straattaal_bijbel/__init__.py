from .verse import Verse
from .dictionary import Dictionary